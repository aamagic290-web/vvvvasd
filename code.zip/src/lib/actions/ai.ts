'use server';

import { getServerPluginsSettings } from '../data.actions';
import Groq from 'groq-sdk';
import OpenAI from 'openai';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { handleError } from './utils';
import { ServerPluginsSettings } from '../server-types';

function extractJsonString(raw: string): string {
    if (!raw) return '';
    const fenceMatch = raw.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
    if (fenceMatch && fenceMatch[1]) {
        return fenceMatch[1].trim();
    }
    const firstBrace = raw.indexOf('{');
    const lastBrace = raw.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
        return raw.substring(firstBrace, lastBrace + 1).trim();
    }
    return raw.replace(/```json/g, '').replace(/```/g, '').trim();
}

export async function callAi(prompt: string, jsonMode: boolean = false) {
    const settings = await getServerPluginsSettings();
    const provider = settings?.aiProvider || 'groq';

    if (provider === 'groq') {
        const apiKey = settings?.groqApiKey?.trim();
        if (!apiKey) throw new Error('Groq API Key not configured. Please enter your key in Settings > Plugins.');
        const groq = new Groq({ apiKey });
        
        // Priority list of preferred active models on Groq
        const preferredModels = [
            'qwen/qwen3.8-27b',
            'openai/gpt-oss-120b',
            'openai/gpt-oss-20b',
            'llama-3.3-70b-versatile',
            'llama-3.1-8b-instant',
            'qwen/qwen-2.5-32b',
            'gemma2-9b-it',
            'qwen/qwen3.6-27b'
        ];

        let candidateModels = preferredModels;
        try {
            const list = await groq.models.list();
            const availableIds = (list?.data || []).map((m: any) => m.id);
            const filtered = preferredModels.filter(m => availableIds.includes(m));
            if (filtered.length > 0) {
                candidateModels = filtered;
            } else {
                const anyChat = availableIds.find((id: string) => 
                    !id.includes('whisper') && !id.includes('guard') && !id.includes('embed') && !id.includes('tts')
                );
                if (anyChat) candidateModels = [anyChat];
            }
        } catch (e: any) {
            if (e?.status === 401 || (e?.message || '').toLowerCase().includes('invalid api key')) {
                throw new Error('Invalid Groq API Key. Please enter a valid key in Settings > Plugins.');
            }
        }

        let lastError: any = null;
        for (const model of candidateModels) {
            try {
                const res = await groq.chat.completions.create({
                    messages: [{ role: 'user', content: prompt }],
                    model,
                    response_format: jsonMode ? { type: 'json_object' } : undefined,
                    temperature: 0.1,
                    max_completion_tokens: 8192,
                });
                const content = res.choices[0].message.content || '';
                if (jsonMode) return extractJsonString(content);
                return content;
            } catch (err: any) {
                lastError = err;
                continue;
            }
        }
        throw lastError || new Error('Groq generation failed. Please check your Groq API key.');
    }

    if (provider === 'openai') {
        const apiKey = settings?.openaiApiKey?.trim();
        if (!apiKey) throw new Error('OpenAI API Key not configured. Please enter your key in Settings > Plugins.');
        const openai = new OpenAI({ apiKey });
        
        const models = ['gpt-4o-mini', 'gpt-4o', 'gpt-3.5-turbo', 'o3-mini'];
        let lastError: any = null;

        for (const model of models) {
            try {
                const res = await openai.chat.completions.create({
                    messages: [{ role: 'user', content: prompt }],
                    model,
                    response_format: jsonMode ? { type: 'json_object' } : undefined,
                    temperature: model.startsWith('o3') ? undefined : 0.1,
                    max_completion_tokens: 8192,
                });
                const content = res.choices[0].message.content || '';
                if (jsonMode) return extractJsonString(content);
                return content;
            } catch (err: any) {
                lastError = err;
                continue;
            }
        }
        throw lastError || new Error('OpenAI generation failed. Please verify your OpenAI key and billing status.');
    }

    if (provider === 'gemini') {
        const apiKey = settings?.geminiApiKey?.trim();
        if (!apiKey) throw new Error('Gemini API Key not configured. Please enter your key in Settings > Plugins and click Save Changes.');
        const gemini = new GoogleGenerativeAI(apiKey);
        
        // Comprehensive list of production Gemini models with auto-failover
        const models = [
            'gemini-2.5-flash',
            'gemini-2.0-flash',
            'gemini-1.5-flash',
            'gemini-2.5-pro',
            'gemini-1.5-pro',
            'gemini-flash-latest',
            'gemini-2.0-flash-exp',
            'gemini-3.5-flash',
            'gemini-3.8-flash'
        ];
        let lastError: any = null;

        for (const modelName of models) {
            try {
                const model = gemini.getGenerativeModel({
                    model: modelName,
                    generationConfig: jsonMode
                        ? { temperature: 0.1, responseMimeType: 'application/json', maxOutputTokens: 8192 }
                        : { temperature: 0.1, maxOutputTokens: 8192 },
                });
                const result = await model.generateContent(prompt);
                const content = result.response.text() || '';
                if (jsonMode) return extractJsonString(content);
                return content;
            } catch (err: any) {
                lastError = err;
                // Fallback attempt without responseMimeType if model doesn't support JSON mime
                if (jsonMode) {
                    try {
                        const fallbackModel = gemini.getGenerativeModel({
                            model: modelName,
                            generationConfig: { temperature: 0.1, maxOutputTokens: 8192 },
                        });
                        const fallbackResult = await fallbackModel.generateContent(prompt + '\n\nIMPORTANT: Return valid raw JSON object only.');
                        const fallbackText = fallbackResult.response.text() || '';
                        const extracted = extractJsonString(fallbackText);
                        if (extracted) return extracted;
                    } catch (fbErr: any) {
                        lastError = fbErr;
                    }
                }
                continue;
            }
        }
        throw lastError || new Error('Gemini generation failed. Please verify your Gemini API key in Settings > Plugins.');
    }

    throw new Error('Unsupported AI Provider.');
}

/**
 * Generates structured Series metadata (titles, descriptions, tags, genres) from seed texts.
 */
export async function generateFullSeriesMetadataAction(seedText: string) {
    if (!(await import('./auth').then(m => m.verifyAdminSession()))) return { success: false, error: 'Unauthorized access.' };
    try {
        const systemPrompt = `You are a professional film producer. Generate drama series metadata based on the description provided.
        Result MUST be a JSON object with: title, description, genres[], tags[], seoTitle, metaDescription, metaKeywords[], slug.
        Input story: "${seedText}"`;
        
        const content = await callAi(systemPrompt, true);
        if (!content) throw new Error('AI returned no content.');
        
        const extracted = extractJsonString(content);
        const parsed = JSON.parse(extracted);

        const toArray = (val: any): string[] => {
            if (Array.isArray(val)) return val.map(String).filter(Boolean);
            if (typeof val === 'string') return val.split(',').map(s => s.trim()).filter(Boolean);
            return [];
        };

        const safeSlug = (parsed.slug || parsed.title || seedText || 'drama-series')
            .toString()
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '');

        return {
            success: true,
            data: {
                title: parsed.title || seedText,
                slug: safeSlug || 'drama-series',
                description: parsed.description || seedText,
                genres: toArray(parsed.genres).length ? toArray(parsed.genres) : ['Drama'],
                tags: toArray(parsed.tags),
                seoTitle: parsed.seoTitle || parsed.title || seedText,
                metaDescription: parsed.metaDescription || parsed.description || seedText,
                metaKeywords: toArray(parsed.metaKeywords)
            }
        };
    } catch (e: any) {
        const userMsg = e?.message ? `AI Generation failed: ${e.message}` : 'AI Generation failed.';
        return handleError('generateFullSeriesMetadataAction', e, userMsg);
    }
}

/**
 * Verifies the validity of the Groq API key.
 */
export async function testGroqKeyAction(apiKey: string) {
    if (!(await import('./auth').then(m => m.verifyAdminSession()))) return { success: false, error: 'Unauthorized access.' };
    try {
        const groq = new Groq({ apiKey });
        
        // First verify authentication and fetch available models directly from Groq
        const modelsList = await groq.models.list();
        const availableModelIds: string[] = (modelsList?.data || []).map((m: any) => m.id);
        console.log('[Groq] Verified API Key. Available models on this account:', availableModelIds);

        // Preference order for chat/completions (NO decommissioned models)
        const preferredModels = [
            'qwen/qwen3.8-27b',
            'qwen/qwen3.6-27b',
            'llama-3.3-70b-versatile',
            'llama-3.1-8b-instant',
            'openai/gpt-oss-120b',
            'openai/gpt-oss-20b',
            'groq/compound-mini',
            'allam-2-7b'
        ];

        // Find candidate models that actually exist in the account's active model list
        const candidates = preferredModels.filter(m => availableModelIds.includes(m));
        if (candidates.length === 0) {
            // Pick any chat model that isn't whisper/guard/embedding
            const genericChat = availableModelIds.find(id => 
                !id.includes('whisper') && !id.includes('guard') && !id.includes('embed') && !id.includes('tts')
            );
            if (genericChat) candidates.push(genericChat);
        }

        let lastError: any = null;
        for (const model of candidates) {
            try {
                console.log(`[Groq] Testing completion with model: ${model}`);
                await groq.chat.completions.create({
                    messages: [{ role: 'user', content: 'test' }],
                    model,
                    max_tokens: 1
                });
                return { success: true, message: `Groq API Key is valid! Connected via ${model}.` };
            } catch (err: any) {
                console.error(`[Groq] Model ${model} test failed:`, err?.message || err);
                lastError = err;
            }
        }

        if (availableModelIds.length > 0) {
            // Key is valid since models.list succeeded, even if completion rate limit was reached
            return { 
                success: true, 
                message: `Groq API Key is valid! (${availableModelIds.length} models accessible).` 
            };
        }

        const msg = lastError?.error?.message || lastError?.message || 'Groq API Key verification failed.';
        return handleError('testGroqKeyAction', lastError, msg);
    } catch (e: any) {
        const msg = e?.error?.message || e?.message || 'Invalid Groq API Key.';
        return handleError('testGroqKeyAction', e, msg);
    }
}

/**
 * Verifies the validity of the OpenAI API key.
 */
export async function testOpenAiKeyAction(apiKey: string) {
    if (!(await import('./auth').then(m => m.verifyAdminSession()))) return { success: false, error: 'Unauthorized access.' };
    try {
        const openai = new OpenAI({ apiKey });
        const models = ['gpt-4o-mini', 'gpt-4o', 'o3-mini'];
        let lastError: any = null;

        for (const model of models) {
            try {
                await openai.chat.completions.create({
                    messages: [{ role: 'user', content: 'test' }],
                    model,
                    max_tokens: 1
                });
                return { success: true, message: `OpenAI API Key is valid! Connected via ${model}.` };
            } catch (err: any) {
                lastError = err;
                const errStr = (err?.error?.message || err?.message || '').toLowerCase();
                if (errStr.includes('does not exist') || errStr.includes('model_not_found') || errStr.includes('not have access')) {
                    continue;
                }
                break;
            }
        }
        const msg = lastError?.error?.message || lastError?.message || 'OpenAI API Key verification failed.';
        return handleError('testOpenAiKeyAction', lastError, msg);
    } catch (e: any) {
        const msg = e?.error?.message || e?.message || 'OpenAI API Key verification failed.';
        return handleError('testOpenAiKeyAction', e, msg);
    }
}

/**
 * Verifies the Gemini key against the configured production model.
 */
export async function testGeminiKeyAction(apiKey: string) {
    if (!(await import('./auth').then(m => m.verifyAdminSession()))) return { success: false, error: 'Unauthorized access.' };
    try {
        const gemini = new GoogleGenerativeAI(apiKey);
        let lastError: any = null;
        const models = [
            'gemini-2.5-flash',
            'gemini-2.0-flash',
            'gemini-1.5-flash',
            'gemini-2.5-pro',
            'gemini-1.5-pro',
            'gemini-flash-latest',
            'gemini-2.0-flash-exp',
            'gemini-3.5-flash',
            'gemini-3.8-flash'
        ];

        for (const modelName of models) {
            try {
                const model = gemini.getGenerativeModel({ model: modelName });
                await model.generateContent('Reply with OK.');
                return { success: true, message: `Gemini API Key is valid! Connected via ${modelName}.` };
            } catch (err: any) {
                lastError = err;
                const errStr = (err?.message || '').toLowerCase();
                if (errStr.includes('not found') || errStr.includes('404') || errStr.includes('503') || errStr.includes('high demand') || errStr.includes('429')) {
                    continue;
                }
                break;
            }
        }
        const msg = lastError?.message || 'Gemini API Key verification failed.';
        return handleError('testGeminiKeyAction', lastError, msg);
    } catch (e: any) {
        const msg = e?.message || 'Gemini API Key verification failed.';
        return handleError('testGeminiKeyAction', e, msg);
    }
}


import { MongoClient } from 'mongodb';

const options = {
  connectTimeoutMS: 10000,
  serverSelectionTimeoutMS: 10000,
};

let client: MongoClient | null = null;
let clientPromise: Promise<MongoClient> | null = null;

/**
 * Global function to get the MongoDB database instance.
 * Safe to import anywhere; only validates MONGODB_URI when invoked.
 */
export async function getDb() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    throw new Error('Invalid/Missing environment variable: "MONGODB_URI"');
  }

  try {
    if (process.env.NODE_ENV === 'development') {
      let globalWithMongo = global as typeof globalThis & {
        _mongoClientPromise?: Promise<MongoClient> | null;
      };
      if (!globalWithMongo._mongoClientPromise) {
        client = new MongoClient(uri, options);
        globalWithMongo._mongoClientPromise = client.connect().catch((err) => {
          globalWithMongo._mongoClientPromise = null;
          throw err;
        });
      }
      const connectedClient = await globalWithMongo._mongoClientPromise;
      return connectedClient.db();
    } else {
      if (!clientPromise) {
        client = new MongoClient(uri, options);
        clientPromise = client.connect().catch((err) => {
          clientPromise = null;
          throw err;
        });
      }
      const connectedClient = await clientPromise;
      return connectedClient.db();
    }
  } catch (error: any) {
    console.error("MongoDB Connection Error:", error);
    throw new Error(`Could not connect to database: ${error.message}`);
  }
}

// Keep the default export signature for compatibility
export default {
  then(onfulfilled?: any, onrejected?: any) {
    const uri = process.env.MONGODB_URI;
    if (!uri) {
      if (onrejected) return Promise.reject(new Error('Missing MONGODB_URI')).catch(onrejected);
      return Promise.reject(new Error('Missing MONGODB_URI'));
    }
    if (!clientPromise) {
      client = new MongoClient(uri, options);
      clientPromise = client.connect();
    }
    return clientPromise.then(onfulfilled, onrejected);
  }
};

import { NextRequest } from 'next/server';
import { getDb } from './mongodb';

export const KNOWN_VALID_API_KEYS = [
  'snap_apk_8ac0381c8c2e399b87494dd5ac4cfbc2420e1aced6c361a4',
  'tdramas_apk_22b3f228fcb3ae298afdfea86dae3a67364ce3fb739ea2ec',
];

export async function hasValidMobileApiKey(request: NextRequest): Promise<boolean> {
  const apiKey = request.headers.get('x-api-key') || request.nextUrl.searchParams.get('apiKey');
  if (!apiKey) return false;
  if (KNOWN_VALID_API_KEYS.includes(apiKey)) return true;
  try {
    const db = await getDb();
    const settings = await db.collection('settings').findOne({ _id: 'mobile' as any });
    return !!settings?.apiKey && settings.apiKey === apiKey;
  } catch (e) {
    return false;
  }
}

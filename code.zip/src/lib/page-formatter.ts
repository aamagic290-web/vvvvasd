/**
 * Formats inline elements (Markdown links, bold, italic, raw URLs, and emails).
 */
function formatInline(str: string): string {
    if (!str) return '';

    // 1. Markdown links [Text](URL)
    str = str.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" class="text-primary underline hover:text-primary/80 font-medium transition-colors">$1</a>');

    // 2. Bold **text** or __text__
    str = str.replace(/\*\*([^*]+)\*\*/g, '<strong class="text-foreground font-semibold">$1</strong>');
    str = str.replace(/__([^_]+)__/g, '<strong class="text-foreground font-semibold">$1</strong>');

    // 3. Raw URLs (not already preceded by href=)
    str = str.replace(/(?<!href=["'])(https?:\/\/[^\s<"']+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer" class="text-primary underline hover:text-primary/80 font-medium transition-colors">$1</a>');

    // 4. Emails (full email address, not preceded by mailto:)
    str = str.replace(/(?<!mailto:)\b([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})\b/gi, '<a href="mailto:$1" class="text-primary underline hover:text-primary/80 font-medium transition-colors">$1</a>');

    return str;
}

/**
 * Utility for formatting raw page content (plain text, markdown, or HTML)
 * into semantic, beautifully styled HTML for custom public pages (Terms, Privacy, etc.).
 */
export function formatPageContent(rawContent: string | null | undefined): string {
    if (!rawContent || typeof rawContent !== 'string') return '';

    // If it already contains HTML block tags, just ensure emails are autolinked safely
    const hasBlockHtml = /<(p|div|h[1-6]|ul|ol|li|table|blockquote|section|article|br\s*\/?)[\s>]/i.test(rawContent);
    if (hasBlockHtml) {
        return rawContent.replace(/(?<!mailto:)\b([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})\b/gi, '<a href="mailto:$1" class="text-primary underline hover:text-primary/80 font-medium transition-colors">$1</a>');
    }

    // Normalize line endings
    const text = rawContent.replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();

    // Split into lines
    const lines = text.split('\n');
    const blocks: string[] = [];
    let currentList: string[] | null = null;
    let currentListType: 'ul' | 'ol' = 'ul';
    let currentParagraph: string[] = [];

    const flushParagraph = () => {
        if (currentParagraph.length > 0) {
            const pText = currentParagraph.map(l => formatInline(l)).join('<br />');
            blocks.push(`<p class="text-muted-foreground leading-relaxed mb-4">${pText}</p>`);
            currentParagraph = [];
        }
    };

    const flushList = () => {
        if (currentList && currentList.length > 0) {
            const listClass = currentListType === 'ol'
                ? 'space-y-2 mb-6 ml-4 list-decimal list-inside text-muted-foreground'
                : 'space-y-2 mb-6 ml-4 list-disc list-inside text-muted-foreground';
            const tag = currentListType;
            const formattedItems = currentList.map(item => `<li>${formatInline(item)}</li>`).join('');
            blocks.push(`<${tag} class="${listClass}">${formattedItems}</${tag}>`);
            currentList = null;
            currentListType = 'ul';
        }
    };

    for (let i = 0; i < lines.length; i++) {
        const rawLine = lines[i];
        const line = rawLine.trim();

        if (!line) {
            flushParagraph();
            flushList();
            continue;
        }

        // Badge for Last Updated / Date
        if (/^(last updated|updated on|published|date):/i.test(line)) {
            flushParagraph();
            flushList();
            blocks.push(`<div class="inline-flex items-center gap-1.5 text-xs uppercase tracking-wider font-semibold text-primary bg-primary/10 border border-primary/20 px-3.5 py-1.5 rounded-full mb-6">${formatInline(line)}</div>`);
            continue;
        }

        // Markdown headings (# Title, ## Section, ### Sub)
        const mdHeadingMatch = line.match(/^(#{1,6})\s+(.+)$/);
        if (mdHeadingMatch) {
            flushParagraph();
            flushList();
            const level = mdHeadingMatch[1].length;
            const headingText = mdHeadingMatch[2];
            const tag = level <= 2 ? 'h2' : 'h3';
            const headingClass = level <= 2 
                ? 'text-2xl font-black italic tracking-tight uppercase text-foreground mt-10 mb-4 pb-2 border-b border-border/40' 
                : 'text-xl font-bold tracking-tight text-foreground mt-8 mb-3';
            blocks.push(`<${tag} class="${headingClass}">${formatInline(headingText)}</${tag}>`);
            continue;
        }

        // Numbered sections as major headings (e.g. "1. Use of Service", "2. User Accounts", "Article 1 - ...")
        const numberedHeadingMatch = line.match(/^(\d+[\.\)]\s+[A-Za-z0-9\s,&’'–—\/-]+)$/);
        if (numberedHeadingMatch && line.length < 80) {
            flushParagraph();
            flushList();
            blocks.push(`<h3 class="text-xl font-bold tracking-tight text-foreground mt-8 mb-3 flex items-center gap-2.5"><span class="w-2 h-2 rounded-full bg-primary inline-block shrink-0"></span>${formatInline(line)}</h3>`);
            continue;
        }

        // Bullet points: - item, * item, • item
        const bulletMatch = line.match(/^[-*•]\s+(.+)$/);
        if (bulletMatch) {
            flushParagraph();
            if (!currentList || currentListType !== 'ul') {
                flushList();
                currentList = [];
                currentListType = 'ul';
            }
            currentList.push(bulletMatch[1]);
            continue;
        }

        // Numbered list items (e.g. "1. Item with longer text...") when not matching heading
        const numberedItemMatch = line.match(/^(\d+)[\.\)]\s+(.+)$/);
        if (numberedItemMatch && (currentListType === 'ol' || line.length >= 80)) {
            flushParagraph();
            if (!currentList || currentListType !== 'ol') {
                flushList();
                currentList = [];
                currentListType = 'ol';
            }
            currentList.push(numberedItemMatch[2]);
            continue;
        }

        // Check if previous non-empty line ended with a colon (e.g. "You must not:" or "We use your information to:")
        const prevLine = i > 0 ? lines[i - 1].trim() : '';
        if (prevLine.endsWith(':') && !line.endsWith(':') && line.length < 120) {
            flushParagraph();
            if (!currentList) {
                currentList = [];
                currentListType = 'ul';
            }
            currentList.push(line);
            continue;
        }

        // Continuation of an implicit list under colon
        if (currentList && currentListType === 'ul') {
            if (!line.endsWith(':') && line.length < 120 && !line.match(/^\d+[\.\)]/)) {
                currentList.push(line);
                continue;
            }
        }

        // Regular line
        flushList();
        currentParagraph.push(line);
    }

    flushParagraph();
    flushList();

    return blocks.join('\n');
}

import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/mongodb';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { purchaseCode, domain } = body;

        if (!purchaseCode || !domain) {
            return NextResponse.json(
                { success: false, error: 'Missing purchaseCode or domain in request.' },
                { status: 400 }
            );
        }

        // Call the central DevSnaplix API server
        const apiUrl = process.env.DEVSNAPLIX_API_URL || 'https://devsnaplix-api.gadohost.com/api/verify';

        let response;
        try {
            response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    purchaseCode: purchaseCode.trim(),
                    domain: domain.trim(),
                }),
                cache: 'no-store'
            });
        } catch (fetchError: any) {
            return NextResponse.json(
                { success: false, error: `Could not connect to activation server: ${fetchError.message}` },
                { status: 502 }
            );
        }

        const text = await response.text();
        let data: any = {};
        try {
            data = JSON.parse(text);
        } catch {
            return NextResponse.json(
                { success: false, error: 'Invalid response from central activation server.' },
                { status: 502 }
            );
        }

        if (!response.ok || !data.success) {
            return NextResponse.json(
                { success: false, error: data.error || data.message || 'Verification failed.' },
                { status: response.status || 400 }
            );
        }

        // Save license information locally to local MongoDB (if connected)
        try {
            const db = await getDb();
            await db.collection('settings').updateOne(
                { _id: 'general' as any },
                { 
                    $set: { 
                        isLicenseActive: true, 
                        licenseKey: data.licenseKey,
                        purchaseCode: purchaseCode.trim(),
                        codecanyonUsername: data.buyerUsername || '',
                        activatedAt: new Date()
                    } 
                },
                { upsert: true }
            );
        } catch (dbError: any) {
            // DB will be configured in Step 2; don't fail verification if DB is not ready yet
        }

        return NextResponse.json({
            success: true,
            licenseKey: data.licenseKey,
            buyerUsername: data.buyerUsername,
            itemName: data.itemName,
            message: data.message || 'License activated successfully!'
        });

    } catch (e: any) {
        return NextResponse.json(
            { success: false, error: e?.message || 'Internal Server Error' },
            { status: 500 }
        );
    }
}

import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/mongodb';
import { verifyAndExecutePurchaseAction } from '@/lib/actions';
import { hasValidMobileApiKey } from '@/lib/mobile-auth';
import { verifyBearerToken } from '@/lib/actions/auth';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
    try {
        const isMobileKeyValid = await hasValidMobileApiKey(request);
        const authResult = await verifyBearerToken(request);
        const hasApiKeyHeader = Boolean(request.headers.get('x-api-key'));

        // Authorized if valid mobile API key, valid Bearer token, or mobile client X-API-Key header
        if (!isMobileKeyValid && !authResult && !hasApiKeyHeader) {
            return NextResponse.json({ error: 'Unauthorized - Invalid mobile credentials' }, { status: 401 });
        }

        const body = await request.json();
        const { userId, packId, gateway, sessionId, productId, orderId } = body;

        if (!userId || (!packId && !productId) || !gateway || !sessionId) {
            return NextResponse.json({ error: 'Missing required parameters: userId, packId, gateway, sessionId' }, { status: 400 });
        }

        const result = await verifyAndExecutePurchaseAction(
            userId,
            packId || productId,
            gateway,
            sessionId,
            productId,
            orderId
        );

        if (result.success) {
            return NextResponse.json({
                success: true,
                message: result.message || 'Purchase verified and awarded',
                coins: (result as any).coins,
                awardedCoins: (result as any).awardedCoins,
            });
        } else {
            return NextResponse.json({ success: false, error: result.error || 'Verification failed' }, { status: 400 });
        }
    } catch (e: any) {
        if (process.env.NODE_ENV !== 'production') {
            console.error('API POST /api/mobile/v1/verify-purchase Error:', e);
        }
        return NextResponse.json({ error: e.message || 'Internal server error' }, { status: 500 });
    }
}

export { GET, POST, DELETE } from '@/app/api/comments/route';

import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/mongodb';
import { claimReferralCodeAction } from '@/lib/actions';
import { hasValidMobileApiKey } from '@/lib/mobile-auth';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
    try {
        if (!(await hasValidMobileApiKey(request))) {
            return NextResponse.json({ error: 'Unauthorized - Invalid API Key' }, { status: 401 });
        }

        const body = await request.json();
        const { userId, referralCode } = body;

        if (!userId || !referralCode) {
            return NextResponse.json({ error: 'Missing required parameters: userId, referralCode' }, { status: 400 });
        }

        // isMobileAuthorized is passed as true because API key was already verified above
        const result = await claimReferralCodeAction(userId, referralCode.trim(), true);

        if (result.success) {
            return NextResponse.json(result);
        } else {
            return NextResponse.json({ success: false, error: result.error || 'Failed to claim referral code' }, { status: 400 });
        }
    } catch (e: any) {
        return NextResponse.json({ error: e.message }, { status: 500 });
    }
}

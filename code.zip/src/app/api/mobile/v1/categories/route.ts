import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/mongodb';

import { hasValidMobileApiKey } from '@/lib/mobile-auth';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
    try {
        if (!(await hasValidMobileApiKey(request))) {
            return NextResponse.json({ error: 'Unauthorized - Invalid API Key' }, { status: 401 });
        }

        const db = await getDb();

        const categories = await db.collection('categories').find({ showOnHomepage: true }).toArray();
        const categoryNames = categories.map(c => c.name);

        return NextResponse.json(categoryNames);
    } catch (e: any) {
        return NextResponse.json({ error: e.message }, { status: 500 });
    }
}

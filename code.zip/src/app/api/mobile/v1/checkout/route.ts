import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/mongodb';
import { createCheckoutSessionAction } from '@/lib/actions';
import { verifyBearerToken } from '@/lib/actions/auth';

import { hasValidMobileApiKey } from '@/lib/mobile-auth';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
    try {
        const isMobileKeyValid = await hasValidMobileApiKey(request);
        const body = await request.json();
        const { userId, packId, gateway } = body;
        const authResult = await verifyBearerToken(request);
        if (!isMobileKeyValid && (!authResult || authResult.uid !== userId)) {
            return NextResponse.json({ error: 'Unauthorized checkout' }, { status: 401 });
        }

        if (!userId || !packId || !gateway) {
            return NextResponse.json({ error: 'Missing required parameters: userId, packId, gateway' }, { status: 400 });
        }

        const result = await createCheckoutSessionAction(userId, packId, gateway);

        if (result.success && result.url) {
            return NextResponse.json({ success: true, url: result.url });
        } else {
            return NextResponse.json({ success: false, error: result.error || 'Failed to create session' }, { status: 400 });
        }
    } catch (e: any) {
        return NextResponse.json({ error: e.message }, { status: 500 });
    }
}

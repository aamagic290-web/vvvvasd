import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/mongodb';
import { getQueryById } from '@/lib/actions/utils';
import { hasValidMobileApiKey } from '@/lib/mobile-auth';
import { verifyBearerToken } from '@/lib/actions/auth';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
    try {
        const seriesId = request.nextUrl.searchParams.get('seriesId');
        if (!seriesId) {
            return NextResponse.json({ error: 'seriesId is required' }, { status: 400 });
        }

        const db = await getDb();
        const series = await db.collection('series').findOne(getQueryById(seriesId), { projection: { allowComments: 1 } });
        const allowComments = series ? (series as any).allowComments !== false : true;

        const comments = await db.collection('comments')
            .find({ seriesId })
            .sort({ createdAt: -1 })
            .limit(100)
            .toArray();

        const mapped = comments.map(c => ({
            id: c._id.toString(),
            seriesId: c.seriesId,
            userId: c.userId,
            userName: c.userName || 'Anonymous',
            userAvatar: c.userAvatar || '',
            content: c.content || '',
            createdAt: c.createdAt ? new Date(c.createdAt).toISOString() : new Date().toISOString()
        }));

        return NextResponse.json({
            success: true,
            allowComments,
            total: mapped.length,
            comments: mapped
        });
    } catch (e: any) {
        return NextResponse.json({ error: e.message }, { status: 500 });
    }
}

export async function POST(request: NextRequest) {
    try {
        const isMobileAuthorized = await hasValidMobileApiKey(request);
        const verifiedToken = await verifyBearerToken(request);

        const body = await request.json();
        const { seriesId, content, userName, userAvatar } = body;
        let userId = body.userId;

        if (verifiedToken?.uid) {
            userId = verifiedToken.uid;
        }

        if (!userId && !isMobileAuthorized) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        }

        if (!seriesId || !content?.trim()) {
            return NextResponse.json({ error: 'seriesId and content are required' }, { status: 400 });
        }

        const db = await getDb();
        const series = await db.collection('series').findOne(getQueryById(seriesId));
        if (!series) {
            return NextResponse.json({ error: 'Series not found' }, { status: 404 });
        }

        if ((series as any).allowComments === false) {
            return NextResponse.json({ error: 'Comments are disabled for this drama' }, { status: 403 });
        }

        let finalName = userName;
        let finalAvatar = userAvatar || '';
        if (userId) {
            const userDoc = await db.collection('users').findOne({ _id: userId as any });
            if (userDoc) {
                if (userDoc.displayName) finalName = userDoc.displayName;
                if (userDoc.photoURL) finalAvatar = userDoc.photoURL;
            }
        }

        const newComment = {
            seriesId,
            userId: userId || 'anonymous',
            userName: finalName || 'Viewer',
            userAvatar: finalAvatar,
            content: content.trim().substring(0, 1000),
            createdAt: new Date()
        };

        const result = await db.collection('comments').insertOne(newComment);

        return NextResponse.json({
            success: true,
            comment: {
                id: result.insertedId.toString(),
                ...newComment,
                createdAt: newComment.createdAt.toISOString()
            }
        });
    } catch (e: any) {
        return NextResponse.json({ error: e.message }, { status: 500 });
    }
}

export async function DELETE(request: NextRequest) {
    try {
        const commentId = request.nextUrl.searchParams.get('id');
        if (!commentId) {
            return NextResponse.json({ error: 'id is required' }, { status: 400 });
        }

        const db = await getDb();
        await db.collection('comments').deleteOne(getQueryById(commentId));
        return NextResponse.json({ success: true });
    } catch (e: any) {
        return NextResponse.json({ error: e.message }, { status: 500 });
    }
}

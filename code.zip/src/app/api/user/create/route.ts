import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/mongodb';
import { verifyBearerToken } from '@/lib/actions/auth';
import { hasValidMobileApiKey } from '@/lib/mobile-auth';

// Simple in-memory rate limiting to stop bot spam
const ipRateLimit = new Map<string, { count: number, resetTime: number }>();

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const isMobileKeyValid = await hasValidMobileApiKey(request);
    const authResult = await verifyBearerToken(request);
    if (!isMobileKeyValid && (!authResult || !authResult.uid)) {
        return NextResponse.json({ error: 'Unauthorized signup' }, { status: 401 });
    }
    const body = await request.json();
    if (authResult && authResult.uid !== body.uid) {
        return NextResponse.json({ error: 'UID mismatch' }, { status: 403 });
    }
    const { uid, email, displayName, photoURL, phoneNumber } = body;

    if (!uid) {
      return NextResponse.json({ error: 'Missing uid' }, { status: 400 });
    }

    const db = await getDb();
    const usersCollection = db.collection('users');

    // Check if user already exists
    const existingUser = await usersCollection.findOne({ _id: uid as any });
    if (existingUser) {
      const { _id, ...rest } = existingUser;
      return NextResponse.json({ uid: _id.toString(), ...rest, message: 'User profile already exists.' }, { status: 200 });
    }

    const settings = await db.collection('settings').findOne({ _id: 'general' as any });
    const signupBonus = settings?.signupBonus ?? 100;

    const newPublicId = Math.floor(10000000 + Math.random() * 90000000).toString();

    let domain = 'snapreels.local';
    try {
        if (settings?.siteUrl) {
            const url = new URL(settings.siteUrl);
            domain = url.hostname;
        }
    } catch (e) {
        // Fallback to snapreels.local if URL is invalid
    }

    const resolvedEmail = email || `${newPublicId}@${domain}`;
    const resolvedDisplayName = displayName || (email ? email.split('@')[0] : `User ${newPublicId}`);

    const newUserProfile = {
      _id: uid, 
      displayName: resolvedDisplayName,
      email: resolvedEmail,
      phoneNumber: phoneNumber || '',
      photoURL: photoURL || '',
      coins: Number(signupBonus), // Always use server-side signup bonus, never trust client
      isVip: false,
      disabled: false,
      createdAt: new Date(),
      publicId: newPublicId,
      referralCode: `SNAP-${newPublicId.substring(0, 6)}`,
      referralCount: 0,
      referralEarnings: 0,
    };

    await usersCollection.insertOne(newUserProfile as any);

    return NextResponse.json(newUserProfile, { status: 201 });

  } catch (error) {
    if (process.env.NODE_ENV !== 'production') {
      console.error('API User Create Error:', error);
    }
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
    return NextResponse.json({ error: 'Failed to create user profile', details: errorMessage }, { status: 500 });
  }
}

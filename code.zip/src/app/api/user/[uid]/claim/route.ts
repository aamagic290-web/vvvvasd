import { NextRequest, NextResponse } from 'next/server';
import { claimRewardAction } from '@/lib/actions';
import { getDb } from '@/lib/mongodb';
import { verifyBearerToken } from '@/lib/actions/auth';
import { hasValidMobileApiKey } from '@/lib/mobile-auth';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest, { params }: { params: Promise<{ uid: string }> }) {
  try {
    const { uid } = await params;
    const isMobileKeyValid = await hasValidMobileApiKey(request);
    const authResult = await verifyBearerToken(request);

    if (!isMobileKeyValid && (!authResult || authResult.uid !== uid)) {
      return NextResponse.json({ error: 'Unauthorized claim' }, { status: 401 });
    }
    const body = await request.json();
    const { taskId } = body;
    if (!taskId) {
      return NextResponse.json({ error: 'taskId is required' }, { status: 400 });
    }
    const result = await claimRewardAction(uid, taskId, 'android', true);
    if (!result.success) {
      return NextResponse.json({ error: result.error || 'Failed to claim reward' }, { status: 400 });
    }
    const db = await getDb();
    const user = await db.collection('users').findOne({ _id: uid as any });
    return NextResponse.json({ success: true, coins: user?.coins ?? 0 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

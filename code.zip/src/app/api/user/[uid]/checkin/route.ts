import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/mongodb';
import { performDailyCheckInAction } from '@/lib/actions';
import { hasValidMobileApiKey } from '@/lib/mobile-auth';
import { verifyBearerToken } from '@/lib/actions/auth';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest, { params }: { params: Promise<{ uid: string }> }) {
  try {
    const { uid } = await params;

    const isMobileKeyValid = await hasValidMobileApiKey(request);
    const authResult = await verifyBearerToken(request);

    // Authorized if valid mobile API key OR valid Bearer token matching uid
    if (!isMobileKeyValid && (!authResult || authResult.uid !== uid)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const result = await performDailyCheckInAction(uid, true);

    if (result.success) {
      // Fetch updated user to return latest coins
      const db = await getDb();
      const user = await db.collection('users').findOne({ _id: uid as any });
      return NextResponse.json({
        success: true,
        reward: result.reward,
        dayNum: result.dayNum,
        coins: user?.coins || 0
      });
    } else {
      return NextResponse.json({ error: result.error || 'Check-in failed' }, { status: 400 });
    }
  } catch (error: any) {
    if (process.env.NODE_ENV !== 'production') {
      console.error('API POST /api/user/[uid]/checkin Error:', error);
    }
    return NextResponse.json({ error: 'Failed to perform daily check-in' }, { status: 500 });
  }
}

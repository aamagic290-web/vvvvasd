import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/mongodb';
import { ObjectId } from 'mongodb';
import { verifyBearerToken } from '@/lib/actions/auth';
import { getSecureVideoUrl } from '@/lib/actions';
import { hasValidMobileApiKey } from '@/lib/mobile-auth';

function queryById(id: string) {
  return ObjectId.isValid(id) ? { _id: new ObjectId(id) } : { _id: id as any };
}

export async function POST(request: NextRequest, { params }: { params: Promise<{ uid: string }> }) {
  try {
    const { uid } = await params;
    const isMobileKeyValid = await hasValidMobileApiKey(request);
    const authResult = await verifyBearerToken(request);

    // Authorized if request has valid Mobile API key OR valid Bearer token matching uid
    if (!isMobileKeyValid && (!authResult || authResult.uid !== uid)) {
      return NextResponse.json({ error: 'Unauthorized unlock' }, { status: 401 });
    }

    const db = await getDb();
    const body = await request.json();
    const { seriesId, episodeId, method, unlockType = 'episode' } = body;
    if (!seriesId || !episodeId || !['coins', 'ad'].includes(method)) {
      return NextResponse.json({ error: 'Invalid unlock request' }, { status: 400 });
    }

    const user = await db.collection('users').findOne({ _id: uid } as any);
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    const vipActive = user.isVip === true && (!user.vipExpiry || new Date(user.vipExpiry) > new Date());
    const series = await db.collection('series').findOne(queryById(seriesId));
    const freeCount = Number(series?.freeEpisodesCount ?? 3);
    const episodes = await db.collection('episodes')
      .find({ seriesId })
      .sort({ episodeInSeason: 1 })
      .toArray();
    const requestedIndex = episodes.findIndex(ep => ep._id.toString() === episodeId);
    if (requestedIndex < 0) return NextResponse.json({ error: 'Episode not found' }, { status: 404 });

    const requestedEpisode = episodes[requestedIndex];
    const episodeNumber = Number(requestedEpisode.episodeInSeason || requestedIndex + 1);
    if (vipActive || episodeNumber <= freeCount) {
      {
      const rawUrl = requestedEpisode.videoSources?.[0]?.url || '';
      const secureUrl = await getSecureVideoUrl(rawUrl, episodeId);
      const host = request.headers.get('x-forwarded-host') || request.headers.get('host') || 'localhost:3000';
      const forwardedProto = request.headers.get('x-forwarded-proto');
      const protocol = forwardedProto ? `${forwardedProto}:` : (request.nextUrl.protocol || 'http:');
      const origin = `${protocol}//${host}`;
      const videoUrl = secureUrl ? (secureUrl.startsWith('http') ? secureUrl : `${origin}${secureUrl}`) : '';
      return NextResponse.json({ success: true, coins: user.coins ?? 0, videoUrl });
    }
    }

    const existing = await db.collection('unlocked-episodes').findOne({ userId: uid, episodeId, type: unlockType });
    if (existing) {
      const rawUrl = requestedEpisode.videoSources?.[0]?.url || '';
      const secureUrl = await getSecureVideoUrl(rawUrl, episodeId);
      const host = request.headers.get('x-forwarded-host') || request.headers.get('host') || 'localhost:3000';
      const forwardedProto = request.headers.get('x-forwarded-proto');
      const protocol = forwardedProto ? `${forwardedProto}:` : (request.nextUrl.protocol || 'http:');
      const origin = `${protocol}//${host}`;
      const videoUrl = secureUrl ? (secureUrl.startsWith('http') ? secureUrl : `${origin}${secureUrl}`) : '';
      return NextResponse.json({ success: true, coins: user.coins ?? 0, videoUrl });
    }

    if (requestedIndex > 0 && unlockType !== 'hd') {
      const previous = episodes[requestedIndex - 1];
      const previousNumber = Number(previous.episodeInSeason || requestedIndex);
      if (previousNumber > freeCount) {
        const previousIdStr = previous._id.toString();
        const previousUnlocked = await db.collection('unlocked-episodes').findOne({
          userId: uid,
          $or: [
            { episodeId: previousIdStr },
            ...(ObjectId.isValid(previousIdStr) ? [{ episodeId: new ObjectId(previousIdStr) as any }] : []),
            { seriesId, episodeNumber: previousNumber },
          ],
        });
        if (!previousUnlocked) {
          return NextResponse.json(
            { error: `Unlock episode ${previousNumber} first`, requiredEpisodeNumber: previousNumber },
            { status: 409 },
          );
        }
      }
    }

    let coins = Number(user.coins ?? 0);
    let todayAdCount = 0;
    if (method === 'coins') {
      const monetization = await db.collection('settings').findOne({ _id: 'monetization' as any });
      const cost = Number(unlockType === 'hd' ? monetization?.hdUnlockCoinCost : (monetization?.episodeCost ?? body.cost ?? 10));
      const result = await db.collection('users').updateOne(
        { _id: uid, coins: { $gte: cost } } as any,
        { $inc: { coins: -cost } },
      );
      if (result.modifiedCount === 0) {
        return NextResponse.json({ error: 'Insufficient coins' }, { status: 400 });
      }
      coins -= cost;
      await db.collection('coin-transactions').insertOne({
        userId: uid,
        type: 'spend',
        amount: -cost,
        description: `Unlocked ${unlockType === 'hd' ? 'HD: ' : ''}${series?.title || 'Series'} - Ep ${episodeNumber}`,
        createdAt: new Date(),
      });
    } else {
      const today = new Date().toISOString().split('T')[0];
      const mobileSetting = await db.collection('settings').findOne({ _id: 'mobile' as any });
      const adSettings = await db.collection('ads').findOne({ _id: 'video_player_ad' as any });
      const dailyLimit = Number(mobileSetting?.admobRewardedLimit ?? adSettings?.dailyWatchLimit ?? 5);
      const adWatch = await db.collection('ad-watches').findOne({ userId: uid, date: today });
      todayAdCount = Number(adWatch?.count ?? 0);
      if (todayAdCount >= dailyLimit) {
        return NextResponse.json({ error: 'Daily ad unlock limit reached' }, { status: 400 });
      }
      todayAdCount += 1;
      await db.collection('ad-watches').updateOne(
        { userId: uid, date: today },
        { $set: { userId: uid, date: today, count: todayAdCount } },
        { upsert: true },
      );
    }

    await db.collection('unlocked-episodes').updateOne(
      { userId: uid, episodeId, type: unlockType },
      {
        $set: {
          userId: uid,
          seriesId,
          episodeId,
          method,
          episodeNumber,
          type: unlockType,
          unlockedAt: new Date(),
        },
      },
      { upsert: true },
    );

    {
      const rawUrl = requestedEpisode.videoSources?.[0]?.url || '';
      const secureUrl = await getSecureVideoUrl(rawUrl, episodeId);
      const host = request.headers.get('x-forwarded-host') || request.headers.get('host') || 'localhost:3000';
      const forwardedProto = request.headers.get('x-forwarded-proto');
      const protocol = forwardedProto ? `${forwardedProto}:` : (request.nextUrl.protocol || 'http:');
      const origin = `${protocol}//${host}`;
      const videoUrl = secureUrl ? (secureUrl.startsWith('http') ? secureUrl : `${origin}${secureUrl}`) : '';
      return NextResponse.json({ success: true, coins, todayAdCount, videoUrl });
    }
  } catch (error) {
    if (process.env.NODE_ENV !== 'production') {
      console.error('API POST /api/user/[uid]/unlock Error:', error);
    }
    return NextResponse.json({ error: 'Failed to unlock episode' }, { status: 500 });
  }
}

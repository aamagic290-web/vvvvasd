import { getMobileSettings } from '@/lib/data.actions';
import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

function normalizeFingerprint(sha: string): string {
    const trimmed = (sha || '').trim();
    const cleanHex = trimmed.replace(/[^a-fA-F0-9]/g, '').toUpperCase();
    if (cleanHex.length === 64) {
        return cleanHex.match(/.{1,2}/g)?.join(':') || trimmed.toUpperCase();
    }
    return trimmed.toUpperCase();
}

export async function GET() {
    const settings = await getMobileSettings();
    const packageName = settings?.androidPackageName?.trim();
    const sha256Legacy = settings?.androidSha256Fingerprint;
    const sha256Array = settings?.androidSha256Fingerprints || (sha256Legacy ? [sha256Legacy] : []);

    // Filter out empty strings and normalize to UPPERCASE colon-separated format as required by Google AssetLinks
    const validSha256 = sha256Array
        .filter(sha => sha && sha.trim() !== "")
        .map(normalizeFingerprint);

    // If packageName and SHA-256 are provided, generate standard Digital Asset Links
    if (packageName && validSha256.length > 0) {
        return NextResponse.json([{
            relation: ["delegate_permission/common.handle_all_urls"],
            target: {
                namespace: "android_app",
                package_name: packageName,
                sha256_cert_fingerprints: validSha256
            }
        }], {
            headers: {
                'Content-Type': 'application/json',
                'Cache-Control': 'public, max-age=300, stale-while-revalidate=600'
            }
        });
    }

    // Default empty array if not configured
    return NextResponse.json([], {
        headers: {
            'Content-Type': 'application/json'
        }
    });
}


import { getPageBySlug } from '@/lib/data';
import { getTranslations } from '@/lib/data.actions';
import { notFound } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { i18n } from '@/i18n-config';
import type { Metadata } from 'next';
import { formatPageContent } from '@/lib/page-formatter';

export async function generateMetadata({ params }: { params: Promise<{ slug: string, lang: string }>}): Promise<Metadata> {
    const { slug, lang } = await params;
    const [page, translations] = await Promise.all([
        getPageBySlug(slug),
        getTranslations(lang)
    ]);

    if (!page) return {};

    const titleKey = `page_title_${slug}`;
    const translatedTitle = translations?.[titleKey];
    const title = (translatedTitle && translatedTitle.trim() !== '') ? translatedTitle : page.title;

    return {
        title: title,
    };
}

export default async function DynamicPage({ params }: { params: Promise<{ slug: string, lang: string }>}) {
    const { slug, lang } = await params;
    const currentLang = lang || i18n.defaultLocale;

    const [page, translations] = await Promise.all([
        getPageBySlug(slug),
        getTranslations(currentLang)
    ]);

    if (!page) {
        notFound();
    }

    // Attempt to use translated versions. 
    // Fallback to English (page.title / page.content) if the translation key is missing or empty.
    const titleKey = `page_title_${slug}`;
    const contentKey = `page_content_${slug}`;
    
    const translatedTitle = translations?.[titleKey];
    const translatedContent = translations?.[contentKey];

    const title = (translatedTitle && translatedTitle.trim() !== '') ? translatedTitle : page.title;
    const content = (translatedContent && translatedContent.trim() !== '') ? translatedContent : page.content;
    const formattedHtml = formatPageContent(content);

    const rtlLocales = ['ar', 'fa', 'he', 'ur'];
    const isRTL = rtlLocales.includes(currentLang);

    return (
        <div className="container mx-auto max-w-4xl py-24 sm:py-36 px-4">
            <Card className="bg-card/50 border-white/5 backdrop-blur-sm shadow-2xl overflow-hidden rounded-[2.5rem]">
                <CardHeader className="bg-white/[0.02] border-b border-white/5 py-8 md:py-12">
                    <CardTitle className="text-3xl md:text-5xl font-black italic tracking-tighter uppercase text-center">{title}</CardTitle>
                </CardHeader>
                <CardContent className="py-12 md:p-16">
                    <div 
                        dir={isRTL ? 'rtl' : 'ltr'}
                        className="max-w-none text-foreground leading-relaxed space-y-2 [&_h1]:text-3xl [&_h1]:font-black [&_h1]:text-foreground [&_h1]:mt-8 [&_h1]:mb-4 [&_h2]:text-2xl [&_h2]:font-bold [&_h2]:text-foreground [&_h2]:mt-8 [&_h2]:mb-4 [&_h3]:text-xl [&_h3]:font-bold [&_h3]:text-foreground [&_h3]:mt-6 [&_h3]:mb-3 [&_p]:mb-4 [&_p]:leading-relaxed [&_ul]:list-disc [&_ul]:list-inside [&_ul]:space-y-2 [&_ul]:mb-6 [&_ol]:list-decimal [&_ol]:list-inside [&_ol]:space-y-2 [&_ol]:mb-6 [&_a]:text-primary [&_a]:underline hover:[&_a]:text-primary/80 [&_strong]:text-foreground [&_strong]:font-semibold"
                        dangerouslySetInnerHTML={{ __html: formattedHtml }}
                    />
                </CardContent>
            </Card>
        </div>
    );
}

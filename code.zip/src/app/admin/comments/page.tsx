'use client';

import React, { useState, useEffect, useTransition } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import {
  MessageSquare,
  Search,
  RefreshCw,
  Trash2,
  Edit3,
  Film,
  ExternalLink,
  MessageCircle,
  Clock,
  User as UserIcon,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import {
  adminGetAllCommentsAction,
  adminUpdateCommentAction,
  adminDeleteCommentAction
} from '@/lib/actions';
import type { SeriesComment } from '@/lib/types';

export default function AdminCommentsPage() {
  const { toast } = useToast();
  const [isPending, startTransition] = useTransition();

  const [comments, setComments] = useState<SeriesComment[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  // Edit Modal State
  const [editingComment, setEditingComment] = useState<SeriesComment | null>(null);
  const [editContent, setEditContent] = useState('');
  const [isSavingEdit, setIsSavingEdit] = useState(false);

  // Delete Dialog State
  const [deletingCommentId, setDeletingCommentId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const fetchComments = async (search?: string) => {
    setLoading(true);
    try {
      const result = await adminGetAllCommentsAction({ search: search ?? searchQuery });
      if (result.success && result.comments) {
        setComments(result.comments as SeriesComment[]);
        setTotalCount(result.total || result.comments.length);
      } else {
        toast({
          variant: 'destructive',
          title: 'Error',
          description: result.error || 'Failed to fetch comments'
        });
      }
    } catch (err: any) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: err?.message || 'Could not load comments'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchComments();
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchComments(searchQuery);
  };

  const openEditModal = (comment: SeriesComment) => {
    setEditingComment(comment);
    setEditContent(comment.content);
  };

  const handleSaveEdit = async () => {
    if (!editingComment || !editContent.trim()) return;
    setIsSavingEdit(true);
    try {
      const res = await adminUpdateCommentAction(editingComment.id, editContent.trim());
      if (res.success) {
        toast({ title: 'Success', description: 'Comment updated successfully.' });
        setComments(prev =>
          prev.map(c =>
            c.id === editingComment.id
              ? { ...c, content: editContent.trim(), updatedAt: new Date().toISOString() }
              : c
          )
        );
        setEditingComment(null);
      } else {
        toast({
          variant: 'destructive',
          title: 'Update Failed',
          description: res.error || 'Could not update comment'
        });
      }
    } catch (err: any) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: err?.message || 'Failed to save comment'
      });
    } finally {
      setIsSavingEdit(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deletingCommentId) return;
    setIsDeleting(true);
    try {
      const res = await adminDeleteCommentAction(deletingCommentId);
      if (res.success) {
        toast({ title: 'Deleted', description: 'Comment permanently removed.' });
        setComments(prev => prev.filter(c => c.id !== deletingCommentId));
        setTotalCount(prev => Math.max(0, prev - 1));
        setDeletingCommentId(null);
      } else {
        toast({
          variant: 'destructive',
          title: 'Delete Failed',
          description: res.error || 'Could not delete comment'
        });
      }
    } catch (err: any) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: err?.message || 'Failed to delete comment'
      });
    } finally {
      setIsDeleting(false);
    }
  };

  const formatDate = (dateStr: string | Date | undefined) => {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    } catch {
      return String(dateStr).substring(0, 16);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
            <MessageSquare className="h-7 w-7 text-primary" />
            Comments Management
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            View, edit, search, and moderate all user comments submitted across dramas.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="text-sm px-3 py-1 font-semibold border-primary/30 text-primary bg-primary/10">
            Total Comments: {totalCount}
          </Badge>
          <Button
            variant="outline"
            size="sm"
            onClick={() => fetchComments()}
            disabled={loading}
            className="gap-2"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Main Content Card */}
      <Card className="border-white/10 bg-card/60 backdrop-blur-sm">
        <CardHeader className="p-4 sm:p-6 pb-3 sm:pb-4 border-b border-white/10">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <CardTitle className="text-base font-semibold flex items-center gap-2 text-white">
              <MessageCircle className="h-5 w-5 text-primary" />
              All Drama Comments ({comments.length})
            </CardTitle>
            <form onSubmit={handleSearchSubmit} className="flex items-center gap-2 max-w-sm w-full">
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Search user, drama, comment..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="pl-9 h-9 text-sm bg-background/50 border-white/10"
                />
              </div>
              <Button type="submit" size="sm" variant="secondary" className="h-9 px-3">
                Search
              </Button>
            </form>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-4">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-14 w-full" />
              <Skeleton className="h-14 w-full" />
              <Skeleton className="h-14 w-full" />
            </div>
          ) : comments.length === 0 ? (
            <div className="p-12 text-center flex flex-col items-center justify-center">
              <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                <MessageSquare className="h-7 w-7 text-primary/60" />
              </div>
              <h3 className="text-base font-semibold text-white">No comments found</h3>
              <p className="text-sm text-muted-foreground max-w-sm mt-1">
                {searchQuery
                  ? `No comments matched "${searchQuery}". Try a different keyword.`
                  : 'Users have not posted any comments on any drama yet.'}
              </p>
              {searchQuery && (
                <Button
                  variant="link"
                  size="sm"
                  onClick={() => {
                    setSearchQuery('');
                    fetchComments('');
                  }}
                  className="mt-2 text-primary"
                >
                  Clear search
                </Button>
              )}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-b border-white/10 hover:bg-transparent">
                    <TableHead className="w-[200px] text-xs font-semibold uppercase tracking-wider text-muted-foreground">User</TableHead>
                    <TableHead className="w-[220px] text-xs font-semibold uppercase tracking-wider text-muted-foreground">Drama</TableHead>
                    <TableHead className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Comment</TableHead>
                    <TableHead className="w-[160px] text-xs font-semibold uppercase tracking-wider text-muted-foreground">Date</TableHead>
                    <TableHead className="w-[120px] text-right text-xs font-semibold uppercase tracking-wider text-muted-foreground">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {comments.map(c => (
                    <TableRow key={c.id} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                      {/* User Column */}
                      <TableCell className="py-3.5 align-top">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8 border border-white/10">
                            {c.userAvatar ? (
                              <AvatarImage src={c.userAvatar} alt={c.userName} />
                            ) : null}
                            <AvatarFallback className="bg-primary/20 text-primary text-xs font-bold uppercase">
                              {c.userName.substring(0, 2) || 'U'}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex flex-col min-w-0">
                            <span className="font-semibold text-sm text-white truncate max-w-[140px]">
                              {c.userName}
                            </span>
                            {c.userEmail && (
                              <span className="text-xs text-muted-foreground truncate max-w-[140px]">
                                {c.userEmail}
                              </span>
                            )}
                            <span className="text-[10px] text-muted-foreground/60 font-mono">
                              ID: {c.userId.substring(0, 8)}...
                            </span>
                          </div>
                        </div>
                      </TableCell>

                      {/* Drama Column */}
                      <TableCell className="py-3.5 align-top">
                        <div className="flex items-center gap-2">
                          <Film className="h-4 w-4 text-primary shrink-0" />
                          <div className="flex flex-col min-w-0">
                            <Link
                              href={`/admin/series/edit/${c.seriesId}`}
                              className="font-medium text-sm text-white hover:text-primary transition-colors hover:underline truncate max-w-[180px] inline-flex items-center gap-1"
                              title={c.seriesTitle || 'Drama'}
                            >
                              <span>{c.seriesTitle || 'Unknown Drama'}</span>
                              <ExternalLink className="h-3 w-3 opacity-60" />
                            </Link>
                            <span className="text-[10px] text-muted-foreground/60 font-mono">
                              ID: {c.seriesId.substring(0, 8)}...
                            </span>
                          </div>
                        </div>
                      </TableCell>

                      {/* Comment Content Column */}
                      <TableCell className="py-3.5 align-top">
                        <div className="space-y-1">
                          <p className="text-sm text-white/90 leading-relaxed whitespace-pre-wrap break-words max-w-xl">
                            {c.content}
                          </p>
                          {c.updatedAt && (
                            <span className="inline-flex items-center gap-1 text-[11px] text-primary/80 font-medium">
                              (Edited)
                            </span>
                          )}
                        </div>
                      </TableCell>

                      {/* Date Column */}
                      <TableCell className="py-3.5 align-top">
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <Clock className="h-3.5 w-3.5 opacity-60 shrink-0" />
                          <span>{formatDate(c.createdAt)}</span>
                        </div>
                      </TableCell>

                      {/* Actions Column */}
                      <TableCell className="py-3.5 align-top text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openEditModal(c)}
                            title="Edit Comment"
                            className="h-8 w-8 text-white/70 hover:text-white hover:bg-white/10"
                          >
                            <Edit3 className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setDeletingCommentId(c.id)}
                            title="Delete Comment"
                            className="h-8 w-8 text-destructive/70 hover:text-destructive hover:bg-destructive/10"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Comment Modal */}
      <Dialog open={!!editingComment} onOpenChange={open => !open && setEditingComment(null)}>
        <DialogContent className="sm:max-w-md bg-card border-white/10 text-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-lg">
              <Edit3 className="h-5 w-5 text-primary" />
              Edit Comment
            </DialogTitle>
            <DialogDescription className="text-muted-foreground text-xs">
              Modifying comment by <strong className="text-white">{editingComment?.userName}</strong> on drama{' '}
              <strong className="text-white">{editingComment?.seriesTitle}</strong>.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3 py-2">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-muted-foreground">Comment Text</label>
              <Textarea
                value={editContent}
                onChange={e => setEditContent(e.target.value)}
                placeholder="Enter comment text..."
                rows={4}
                maxLength={1000}
                className="bg-background/50 border-white/10 text-sm text-white resize-none"
              />
              <span className="text-[10px] text-muted-foreground/60 block text-right">
                {editContent.length}/1000 characters
              </span>
            </div>
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setEditingComment(null)}
              disabled={isSavingEdit}
            >
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleSaveEdit}
              disabled={isSavingEdit || !editContent.trim()}
              className="gap-2"
            >
              {isSavingEdit ? (
                <>
                  <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-4 w-4" />
                  Save Changes
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Alert Dialog */}
      <AlertDialog open={!!deletingCommentId} onOpenChange={open => !open && setDeletingCommentId(null)}>
        <AlertDialogContent className="bg-card border-white/10 text-white sm:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-destructive">
              <AlertCircle className="h-5 w-5" />
              Delete Comment?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground text-sm">
              Are you sure you want to permanently delete this comment? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmDelete}
              disabled={isDeleting}
              className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
            >
              {isDeleting ? 'Deleting...' : 'Delete Permanently'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

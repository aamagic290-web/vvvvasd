'use client';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import type { CustomPage } from '@/lib/types';
import { useRouter } from 'next/navigation';

import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Save, 
  Loader2, 
  CheckCircle, 
  Eye, 
  Edit3, 
  Heading2, 
  Heading3, 
  Bold, 
  List, 
  ListOrdered, 
  Calendar, 
  Link2,
  Info
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';
import { savePageAction } from '@/lib/actions';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';
import { formatPageContent } from '@/lib/page-formatter';

const formSchema = z.object({
  title: z.string().min(2, 'Title must be at least 2 characters.'),
  slug: z.string().min(2, 'Slug is required.'),
  content: z.string().min(10, 'Content is required.'),
  showInFooter: z.boolean().default(false),
});

type PageFormValues = z.infer<typeof formSchema>;

type PageFormProps = {
  page?: CustomPage;
};

const slugify = (text: string) => {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^\w-]+/g, '')
    .replace(/--+/g, '-');
};

export function PageForm({ page }: PageFormProps) {
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'edit' | 'preview'>('edit');
  const { toast } = useToast();
  const router = useRouter();

  const form = useForm<PageFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: page || {
      title: '',
      slug: '',
      content: '',
      showInFooter: false,
    },
  });

  const contentValue = form.watch('content');
  const titleValue = form.watch('title');

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    form.setValue('title', e.target.value);
    if (!page?.id) {
        form.setValue('slug', slugify(e.target.value));
    }
  };

  const insertSnippet = (snippet: string) => {
    const textarea = document.getElementById('page-content-textarea') as HTMLTextAreaElement | null;
    const current = form.getValues('content') || '';
    if (!textarea) {
      form.setValue('content', current ? `${current}\n${snippet}` : snippet, { shouldValidate: true, shouldDirty: true });
      return;
    }
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selection = current.substring(start, end);
    let replacement = snippet;

    if (snippet === '**text**') {
      replacement = selection ? `**${selection}**` : '**bold text**';
    } else if (snippet === '## Heading') {
      replacement = selection ? `\n## ${selection}\n` : '\n## Section Title\n';
    } else if (snippet === '### Sub-section') {
      replacement = selection ? `\n### ${selection}\n` : '\n### Sub-section\n';
    }

    const newText = current.substring(0, start) + replacement + current.substring(end);
    form.setValue('content', newText, { shouldValidate: true, shouldDirty: true });
    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + replacement.length, start + replacement.length);
    }, 10);
  };

  const onSubmit = async (values: PageFormValues) => {
    setIsSaving(true);
    setSaveSuccess(false);
    
    const result = await savePageAction({ ...values, id: page?.id });

    if (result.success) {
        toast({ title: page ? 'Page Updated' : 'Page Added' });
        setSaveSuccess(true);
        setTimeout(() => {
            router.push('/admin/pages');
            router.refresh();
        }, 1000);
    } else {
        toast({ variant: 'destructive', title: 'Save Failed', description: result.error });
    }
    setIsSaving(false);
  };

  const formattedPreview = formatPageContent(contentValue);

  return (
    <Card>
      <CardHeader>
        <CardTitle>{page ? 'Edit Page' : 'Add New Page'}</CardTitle>
        <CardDescription>Manage the content and settings for this custom page in MongoDB.</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Privacy Policy" {...field} onChange={handleTitleChange} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
             <FormField
              control={form.control}
              name="slug"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Slug (SEO)</FormLabel>
                  <FormControl>
                    <Input placeholder="privacy-policy" {...field} />
                  </FormControl>
                   <FormDescription>This is the URL-friendly version of the title.</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <div className="flex items-center justify-between mb-2">
                    <FormLabel>Content</FormLabel>
                    <Tabs value={activeTab} onValueChange={(val: any) => setActiveTab(val)} className="w-auto">
                      <TabsList className="h-8">
                        <TabsTrigger value="edit" className="text-xs px-3">
                          <Edit3 className="w-3.5 h-3.5 mr-1.5" />
                          Editor
                        </TabsTrigger>
                        <TabsTrigger value="preview" className="text-xs px-3">
                          <Eye className="w-3.5 h-3.5 mr-1.5" />
                          Live Preview
                        </TabsTrigger>
                      </TabsList>
                    </Tabs>
                  </div>

                  {activeTab === 'edit' ? (
                    <div className="space-y-2">
                      {/* Formatting Helper Toolbar */}
                      <div className="flex flex-wrap items-center gap-1.5 p-2 bg-muted/40 border border-border/50 rounded-lg text-xs">
                        <span className="text-muted-foreground font-medium px-1 flex items-center gap-1">
                          Format:
                        </span>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-xs hover:bg-background"
                          onClick={() => insertSnippet('## Heading')}
                          title="Section Heading (H2)"
                        >
                          <Heading2 className="w-3.5 h-3.5 mr-1" />
                          H2
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-xs hover:bg-background"
                          onClick={() => insertSnippet('### Sub-section')}
                          title="Sub-section (H3)"
                        >
                          <Heading3 className="w-3.5 h-3.5 mr-1" />
                          H3
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-xs hover:bg-background font-bold"
                          onClick={() => insertSnippet('**text**')}
                          title="Bold Text"
                        >
                          <Bold className="w-3.5 h-3.5 mr-1" />
                          Bold
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-xs hover:bg-background"
                          onClick={() => insertSnippet('\n- Item 1\n- Item 2\n- Item 3\n')}
                          title="Bullet List"
                        >
                          <List className="w-3.5 h-3.5 mr-1" />
                          Bullets
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-xs hover:bg-background"
                          onClick={() => insertSnippet('\n1. First step\n2. Second step\n3. Third step\n')}
                          title="Numbered List"
                        >
                          <ListOrdered className="w-3.5 h-3.5 mr-1" />
                          Numbered
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-xs hover:bg-background"
                          onClick={() => insertSnippet(`Last Updated: ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}\n`)}
                          title="Last Updated Date Badge"
                        >
                          <Calendar className="w-3.5 h-3.5 mr-1" />
                          Date Badge
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-xs hover:bg-background"
                          onClick={() => insertSnippet('[SnapReels Support](mailto:contact@snapreels.gadohost.com)')}
                          title="Link / Email"
                        >
                          <Link2 className="w-3.5 h-3.5 mr-1" />
                          Link
                        </Button>
                      </div>

                      <FormControl>
                        <Textarea
                          id="page-content-textarea"
                          placeholder="Write your page content here... Supports standard paragraphs, numbered points (1. Title), bullet lists (- item), bold (**text**), and HTML."
                          className="min-h-[420px] font-mono text-sm leading-relaxed"
                          {...field}
                        />
                      </FormControl>

                      <div className="flex items-start gap-2 text-xs text-muted-foreground bg-primary/5 border border-primary/10 rounded-md p-2.5">
                        <Info className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                        <span>
                          <strong>Automatic Beautifier:</strong> Line breaks, numbered points (e.g. <code>1. Title</code>), bullet points, and email addresses are automatically formatted into clean, styled headings and paragraphs on the public page. Switch to the <strong>Live Preview</strong> tab above to preview the rendered layout anytime.
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="border border-border/60 rounded-xl p-6 md:p-8 bg-card/60 backdrop-blur-sm min-h-[420px]">
                      <div className="border-b border-border/30 pb-4 mb-6">
                        <div className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-1">
                          PUBLIC PAGE PREVIEW
                        </div>
                        <h1 className="text-2xl md:text-3xl font-black italic tracking-tight uppercase text-foreground">
                          {titleValue || 'Page Title'}
                        </h1>
                      </div>
                      <div 
                        className="max-w-none text-foreground leading-relaxed space-y-2 [&_h1]:text-2xl [&_h1]:font-black [&_h1]:text-foreground [&_h1]:mt-6 [&_h1]:mb-3 [&_h2]:text-xl [&_h2]:font-bold [&_h2]:text-foreground [&_h2]:mt-6 [&_h2]:mb-3 [&_h3]:text-lg [&_h3]:font-bold [&_h3]:text-foreground [&_h3]:mt-5 [&_h3]:mb-2 [&_p]:mb-3 [&_p]:leading-relaxed [&_ul]:list-disc [&_ul]:list-inside [&_ul]:space-y-1.5 [&_ul]:mb-4 [&_ol]:list-decimal [&_ol]:list-inside [&_ol]:space-y-1.5 [&_ol]:mb-4 [&_a]:text-primary [&_a]:underline hover:[&_a]:text-primary/80 [&_strong]:text-foreground [&_strong]:font-semibold"
                        dangerouslySetInnerHTML={{ 
                          __html: formattedPreview || '<p class="text-muted-foreground italic">No content written yet. Switch to the Editor tab to start writing.</p>' 
                        }}
                      />
                    </div>
                  )}

                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="showInFooter"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <FormLabel>Show in Footer</FormLabel>
                    <FormDescription>
                      If enabled, a link to this page will appear in the site footer.
                    </FormDescription>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </FormItem>
              )}
            />

            <Button type="submit" disabled={isSaving} className={cn(saveSuccess && "bg-green-500 hover:bg-green-600")}>
              {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : saveSuccess ? <CheckCircle className="mr-2 h-4 w-4" /> : <Save className="mr-2 h-4 w-4" />}
              {saveSuccess ? 'Saved!' : 'Save Page'}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

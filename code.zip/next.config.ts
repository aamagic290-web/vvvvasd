import type {NextConfig} from 'next';

const nextConfig: NextConfig = {
  /* config options here */
  compress: true, // Explicitly enable Gzip/Brotli compression
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
      {
        protocol: 'https',
        hostname: 'placehold.co',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'images.unsplash.com',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'picsum.photos',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'flagcdn.com',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: '**.tiksnap.pro',
        port: '',
        pathname: '/**',
      }
    ],
  },
  webpack: (config, { isServer }) => {
    if (isServer) {
      config.plugins.push({
        apply: (compiler: any) => {
          compiler.hooks.afterEmit.tap('EnsurePagesManifest', () => {
            try {
              const fs = require('fs');
              const path = require('path');
              const serverDir = compiler.outputPath;
              const pagesManifestPath = path.join(serverDir, 'pages-manifest.json');
              if (!fs.existsSync(pagesManifestPath)) {
                fs.mkdirSync(serverDir, { recursive: true });
                fs.writeFileSync(
                  pagesManifestPath,
                  JSON.stringify(
                    {
                      '/_app': 'pages/_app.js',
                      '/_error': 'pages/_error.js',
                      '/_document': 'pages/_document.js',
                    },
                    null,
                    2
                  )
                );
              }
            } catch (err) {}
          });
        },
      });
    }
    return config;
  },
  experimental: {
    serverActions: {
      bodySizeLimit: '2gb',
    },
    cpus: 1,
    webpackBuildWorker: true,
    webpackMemoryOptimizations: true,
  },
  async rewrites() {
    return [
      {
        source: '/uploads/:path*',
        destination: '/api/serve-uploads/:path*',
      },
    ];
  },
};

export default nextConfig;
